from __future__ import annotations

import re


_REMOVE_PHRASES = [
    "On the screen, I see",
    "I can see that",
    "I see that",
    "Based on the screen",
    "As your AI assistant",
    "I notice that",
    "It appears that",
    "I would recommend",
    "Please note that",
    "I am here to help",
    "Ready to assist",
    "How can I help",
    "Is there anything",
    "As an AI",
    "Certainly!",
    "Sure!",
    "Great!",
    "Of course!",
]

_REPLACE_PREFIXES = [
    "I have detected",
    "I would suggest",
    "It seems like",
]


def clean_response(text: str) -> str:
    cleaned = (text or "").strip()
    if not cleaned:
        return ""
    cleaned = remove_lists(cleaned)

    for phrase in _REMOVE_PHRASES:
        cleaned = re.sub(re.escape(phrase), "", cleaned, flags=re.IGNORECASE)

    for prefix in _REPLACE_PREFIXES:
        cleaned = re.sub(rf"\\b{re.escape(prefix)}\\b", "", cleaned, flags=re.IGNORECASE)

    cleaned = cleaned.replace("!", ".")
    cleaned = re.sub(r"\\s+", " ", cleaned).strip()
    cleaned = re.sub(r"^[,.:;\\s]+", "", cleaned).strip()
    cleaned = re.sub(r"[\\s,.:;]+$", "", cleaned).strip()
    return cleaned


def clean_response_proactive(text: str) -> str:
    cleaned = clean_response(text)
    if not cleaned:
        return ""
    sentences = re.split(r"(?<=[.!?])\\s+", cleaned)
    if len(sentences) > 2:
        cleaned = " ".join(sentences[:2]).strip()
    return cleaned


def remove_lists(text: str) -> str:
    lines = text.split("\\n")
    cleaned: list[str] = []
    for line in lines:
        stripped = line.strip()
        if re.match(r"^\\d+\\.", stripped):
            content = re.sub(r"^\\d+\\.\\s*", "", stripped)
            cleaned.append(content)
        elif stripped.startswith(("-", "*", "•", "–")):
            content = stripped.lstrip("-*•– ")
            cleaned.append(content)
        else:
            cleaned.append(line)
    return "\\n".join(cleaned).strip()
