from __future__ import annotations

import asyncio
import json
import re
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Callable
import uuid

import requests

from screensense.config import Settings
from screensense.core.response_cleaner import clean_response, clean_response_proactive
from screensense.core.ui_context import UiContextExtractor, UiContextSettings
from screensense.core.window_context import get_active_window_context
from screensense.core.capture import ScreenCapturer
from screensense.core.action_gate import ActionGate
from screensense.memory.sqlite_store import SQLiteMemoryStore
from screensense.perception.ui_context import UiAutomationContext
from screensense.skills.code_ops import CodeOps
from screensense.skills.browser_ops import BrowserOps
from screensense.skills.file_ops import FileOps
from screensense.skills.system_ops import SystemOps

try:
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
    from telegram.error import InvalidToken
    from telegram.ext import (
        Application,
        ApplicationBuilder,
        CallbackQueryHandler,
        CommandHandler,
        ContextTypes,
        MessageHandler,
        filters,
    )
except Exception:  # pragma: no cover
    Application = None  # type: ignore[assignment]
    InvalidToken = None  # type: ignore[assignment]


@dataclass(slots=True)
class PendingAction:
    action_fn: Callable[[], str] | None
    reasoning: str


@dataclass(slots=True)
class PendingApproval:
    event: threading.Event
    result: bool | None


class ARIATelegramBot:
    def __init__(
        self,
        *,
        settings: Settings,
        memory_db: SQLiteMemoryStore,
        ui_context_provider: UiAutomationContext | None = None,
        ui_context_extractor: UiContextExtractor | None = None,
    ) -> None:
        self._settings = settings
        self._memory_db = memory_db
        self._token = settings.telegram_bot_token.strip()
        self._chat_id = settings.telegram_chat_id.strip()
        self._ui_context_provider = ui_context_provider or UiAutomationContext()
        self._ui_context_extractor = ui_context_extractor or UiContextExtractor(
            UiContextSettings(
                enabled=settings.enable_ocr_context,
                provider=settings.ocr_provider,
                min_interval_seconds=settings.ocr_min_interval_seconds,
                max_text_chars=settings.ocr_max_text_chars,
            )
        )
        self._capture_local = threading.local()
        self._app: Application | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._pending_action = PendingAction(action_fn=None, reasoning="")
        self._last_error: str = ""
        self._last_error_ts: float = 0.0
        self._approvals_lock = threading.Lock()
        self._pending_approvals: dict[str, PendingApproval] = {}
        self._goal_callback: Callable[[str], str | None] | None = None
        self._health_callback: Callable[[], str] | None = None
        self._killlocal_callback: Callable[[], str] | None = None
        skill_allowlist = {
            "read_file",
            "list_directory",
            "find_files",
            "git_status",
            "get_syntax_errors",
            "search_web",
            "open_url",
            "search_docs",
            "search_stackoverflow",
            "copy_to_clipboard",
            "show_notification",
        }
        self._action_gate = ActionGate(
            allowlist=list(settings.action_allowlist) + sorted(skill_allowlist),
            telegram_request_approval=self.request_approval,
            whisper_callback=None,
            log_callback=None,
        )
        self._code_ops = CodeOps(self._action_gate)
        self._browser_ops = BrowserOps(self._action_gate)
        self._file_ops = FileOps(approval_callback=self._approve_file_write)
        self._system_ops = SystemOps(self._action_gate)
        print("[TG] skills loaded:", self._browser_ops, self._file_ops, self._code_ops)

    def start(self) -> bool:
        if Application is None:
            return False
        if not self._token or not self._chat_id:
            return False
        if not self._looks_like_token(self._token):
            return False
        if self._thread and self._thread.is_alive():
            return True
        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name="ARIA-Telegram",
        )
        self._thread.start()
        return True

    def send_message(self, text: str) -> None:
        if not self._loop or not self._app:
            return
        cleaned = clean_response_proactive(text)
        if not cleaned:
            return
        asyncio.run_coroutine_threadsafe(
            self._app.bot.send_message(chat_id=self._chat_id, text=cleaned),
            self._loop,
        )

    def stop(self) -> None:
        if not self._loop or not self._app:
            return
        asyncio.run_coroutine_threadsafe(self._shutdown_async(), self._loop)

    def send_proactive_alert(
        self,
        *,
        message: str,
        reasoning: str,
        action_fn: Callable[[], str] | None = None,
    ) -> None:
        if not self._loop or not self._app:
            return
        cleaned = clean_response_proactive(message)
        if not cleaned:
            return
        self._pending_action = PendingAction(action_fn=action_fn, reasoning=reasoning or "")
        markup = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("✓ Do it", callback_data="action_do"),
                    InlineKeyboardButton("✕ Skip", callback_data="action_skip"),
                    InlineKeyboardButton("? More info", callback_data="action_more"),
                ]
            ]
        )
        asyncio.run_coroutine_threadsafe(
            self._app.bot.send_message(
                chat_id=self._chat_id,
                text=cleaned,
                reply_markup=markup,
            ),
            self._loop,
        )

    def request_approval(self, preview: str, timeout_seconds: float) -> bool | None:
        if not self._loop or not self._app:
            return None
        request_id = uuid.uuid4().hex[:10]
        event = threading.Event()
        with self._approvals_lock:
            self._pending_approvals[request_id] = PendingApproval(event=event, result=None)
        markup = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("✓ Yes", callback_data=f"approve:{request_id}:yes"),
                    InlineKeyboardButton("✕ No", callback_data=f"approve:{request_id}:no"),
                ]
            ]
        )
        asyncio.run_coroutine_threadsafe(
            self._app.bot.send_message(
                chat_id=self._chat_id,
                text=preview,
                reply_markup=markup,
            ),
            self._loop,
        )
        event.wait(timeout_seconds)
        with self._approvals_lock:
            pending = self._pending_approvals.pop(request_id, None)
        if pending is None:
            return None
        return pending.result

    def _run(self) -> None:
        if Application is None:
            return
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        self._loop = loop
        self._app = ApplicationBuilder().token(self._token).build()
        self._register_handlers(self._app)
        try:
            loop.run_until_complete(self._startup_async())
            loop.run_forever()
        except Exception:
            return

    async def _startup_async(self) -> None:
        if self._app is None:
            return
        try:
            await self._app.initialize()
            await self._app.start()
            if self._app.updater is not None:
                await self._app.updater.start_polling()
            try:
                await self._send_startup_message()
            except Exception:
                pass
        except Exception:
            await self._shutdown_async()

    async def _shutdown_async(self) -> None:
        if self._app is None:
            return
        try:
            if self._app.updater is not None:
                await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
        finally:
            if self._loop is not None:
                self._loop.stop()

    def _register_handlers(self, app: Application) -> None:
        app.add_handler(CommandHandler("status", self._on_status))
        app.add_handler(CommandHandler("killlocal", self._on_killlocal))
        app.add_handler(CommandHandler("health", self._on_health))
        app.add_handler(CommandHandler("focus", self._on_focus))
        app.add_handler(CommandHandler("resume", self._on_resume))
        app.add_handler(CommandHandler("goal", self._on_goal))
        app.add_handler(CommandHandler("clear", self._on_clear))
        app.add_handler(CallbackQueryHandler(self._on_callback))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._on_message))

    async def _send_startup_message(self) -> None:
        if self._app is None:
            return
        now = datetime.now()
        time_str = now.strftime("%H:%M")
        days_left = self._days_to_deadline(now)
        if days_left is None:
            deadline_text = "deadline not set."
        else:
            deadline_text = f"{days_left} days to deadline."
        text = f"ARIA online. {time_str}. {deadline_text}"
        try:
            await self._app.bot.send_message(chat_id=self._chat_id, text=text)
        except Exception as exc:
            self._record_error(f"startup_message_failed: {exc}")

    async def _on_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None or update.message.text is None:
            return
        user_text = update.message.text.strip()
        print(f"[TG] received: {user_text}")
        if not user_text:
            return
        try:
            goal_response = None
            if hasattr(self, "_goal_callback") and self._goal_callback is not None:
                goal_response = self._goal_callback(user_text)
            if goal_response:
                await update.message.reply_text(goal_response)
                self._memory_db.add_telegram_message(role="user", content=user_text)
                self._memory_db.add_telegram_message(role="assistant", content=goal_response)
                return
            message_lower = user_text.lower()
            try:
                ui_context = await self._capture_ui_context_async()
                print(f"[TG] ui_context: {ui_context}")
            except Exception as exc:
                print(f"[TG] ui_context FAILED: {exc}")
                ui_context = {}

            if any(w in message_lower for w in ["search", "find", "look up", "google"]):
                print("[TG] → intent: SEARCH")
                try:
                    results = await asyncio.to_thread(self._browser_ops.search_web_api, user_text)
                    print(f"[TG] search results: {results[:200]}")
                except Exception as exc:
                    print(f"[TG] search FAILED: {exc}")
                    results = ""
                if not results:
                    await update.message.reply_text("search returned nothing")
                    return
                prompt = (
                    f"Real search results for: {user_text}\n\n"
                    f"{results}\n\n"
                    "Summarise in 2 sentences. "
                    "Give 2 real URLs from above. "
                    "No lists. No bullets. Plain sentences. "
                    "Do not use training knowledge. "
                    "Only use the results above.\n"
                    "ARIA:"
                )
                response = self._generate_response(prompt)
                response = clean_response(response)
                print(f"[TG] → sending: {response[:100]}")
                await update.message.reply_text(response)
                return

            if (
                any(w in message_lower for w in ["open", "visit", "go to"])
                or "http" in message_lower
                or any(message_lower.endswith(tld) for tld in [".com", ".org", ".io", ".dev"])
            ):
                print("[TG] → intent: OPEN_URL")
                url = _extract_url(user_text or "")
                print(f"[TG] extracted url: {url}")
                if not url:
                    await update.message.reply_text("what URL should I open?")
                    return
                print(f"[TG] opening URL: {url}")
                try:
                    content = await self._browser_ops.open_url_async(url)
                    print(f"[TG] page content: {len(content)} chars")
                except Exception as exc:
                    print(f"[TG] open_url FAILED: {exc}")
                    content = ""
                if not content:
                    await update.message.reply_text(
                        f"opened {url} but could not read content"
                    )
                    return
                prompt = (
                    f"Page content from {url}:\n\n"
                    f"{content[:1500]}\n\n"
                    "Describe what this page is about in 3 sentences using only the above content. "
                    "No lists. No bullets.\n"
                    "ARIA:"
                )
                response = self._generate_response(prompt)
                response = clean_response(response)
                await update.message.reply_text(response)
                return

            if any(
                w in message_lower
                for w in ["files", "folder", "directory", "project", "what is in"]
            ):
                print("[TG] → intent: FILES")
                try:
                    files = self._file_ops.list_directory(".")
                    print(f"[TG] files: {files}")
                    file_list = ", ".join(files[:20])
                except Exception as exc:
                    print(f"[TG] file list FAILED: {exc}")
                    file_list = ""
                if not file_list:
                    await update.message.reply_text("could not read directory")
                    return
                response = f"project has: {file_list}"
                await update.message.reply_text(clean_response(response))
                return

            if any(
                w in message_lower
                for w in ["working on", "screen", "see", "what is open", "current"]
            ):
                print("[TG] → intent: SCREEN")
                if not ui_context:
                    await update.message.reply_text("cannot read screen right now")
                    return
                prompt = (
                    f"Shwet asked: {user_text}\n\n"
                    f"Current screen context:\n{json.dumps(ui_context, indent=2)}\n\n"
                    "Answer in 2 sentences using only the above real screen data. "
                    "No hallucination. No guessing.\n"
                    "ARIA:"
                )
                response = self._generate_response(prompt)
                await update.message.reply_text(clean_response(response))
                return

            print("[TG] -> intent: CHAT")
            prompt = (
                "You are ARIA.\n"
                "Not a chatbot. Never say 'How can I assist'.\n"
                "Never say 'Sure'. Never ask open questions.\n"
                "Max 2 sentences. No markdown.\n"
                "You know what's on Shwet's screen.\n"
                "State what you know. Be direct.\n\n"
                f"Current screen: {json.dumps(ui_context)}\n"
                f"Message: {user_text}\n"
                "ARIA:"
            )
            response = self._generate_response(prompt)
            await update.message.reply_text(clean_response(response))
        except Exception as exc:
            import traceback

            self._record_error(f"message_handler_failed: {exc}")
            print("[Telegram] FULL ERROR:")
            traceback.print_exc()
            try:
                await update.message.reply_text(f"failed: {type(exc).__name__}: {exc}")
            except Exception:
                pass

    async def _on_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.callback_query is None:
            return
        query = update.callback_query
        await query.answer()
        data = (query.data or "").strip()
        if data.startswith("approve:"):
            parts = data.split(":")
            if len(parts) == 3:
                request_id = parts[1]
                decision = parts[2].lower() == "yes"
                with self._approvals_lock:
                    pending = self._pending_approvals.get(request_id)
                if pending is not None:
                    pending.result = decision
                    pending.event.set()
                    await query.message.reply_text("ok" if not decision else "done.")
            return
        if data == "action_do":
            result = self._execute_pending_action()
            await query.message.reply_text(result)
        elif data == "action_skip":
            self._log_skip()
            await query.message.reply_text("ok")
        elif data == "action_more":
            reasoning = self._pending_action.reasoning.strip() or "No additional details."
            await query.message.reply_text(reasoning)

    async def _on_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        summary = self._build_status_summary()
        health = self._health_callback() if self._health_callback is not None else ""
        text = f"{summary}\n{health}".strip()
        await update.message.reply_text(text)

    async def _on_killlocal(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        if self._killlocal_callback is None:
            await update.message.reply_text("local model not configured.")
            return
        response = self._killlocal_callback()
        await update.message.reply_text(response)

    async def _on_health(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        status = "running" if self._thread and self._thread.is_alive() else "stopped"
        if self._last_error:
            ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self._last_error_ts))
            text = f"telegram {status}. last_error {ts}: {self._last_error}"
        else:
            text = f"telegram {status}. no errors recorded."
        await update.message.reply_text(text)

    async def _on_focus(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        self._settings.focus_mode = True
        await update.message.reply_text("quiet mode on.")

    async def _on_resume(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        self._settings.focus_mode = False
        recent = self._memory_db.recent_interactions(limit=3)
        if recent:
            summary = "; ".join(recent)
            text = f"back. anything happen? recent: {summary}"
        else:
            text = "back. anything happen? nothing logged yet."
        await update.message.reply_text(text)

    async def _on_goal(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        text = (update.message.text or "").strip()
        parts = text.split(maxsplit=1)
        if len(parts) < 2:
            await update.message.reply_text("got it.")
            return
        goal_text = parts[1].strip()
        if goal_text:
            self._memory_db.set_today_goal(self._today_key(), goal_text)
        await update.message.reply_text("got it.")

    async def _on_clear(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        self._memory_db.clear_telegram_history()
        await update.message.reply_text("memory cleared.")

    async def _capture_ui_context_async(self) -> dict[str, object]:
        active = get_active_window_context()
        try:
            ui_result = self._ui_context_provider.capture()
        except Exception:
            ui_result = None
        stack_hint = ""
        if ui_result is not None:
            error_text = self._extract_error_text(ui_result.context)
            if error_text:
                stack_hint = await asyncio.to_thread(
                    self._browser_ops.search_stackoverflow, error_text
                )
        frame = None
        try:
            frame = self._get_capturer().capture_rgb()
        except Exception:
            frame = None
        app_context: dict[str, str | int | bool | None] = {
            "window_title": active.title,
            "process_name": active.process_name,
            "executable_name": active.executable_name,
            "pid": active.pid,
        }
        if frame is not None:
            enriched = self._ui_context_extractor.enrich(frame_rgb=frame, app_context=app_context)
        else:
            enriched = dict(app_context)
        return {
            "active_window": {
                "title": active.title,
                "process_name": active.process_name,
                "executable_name": active.executable_name,
                "pid": active.pid,
            },
            "ui_context": ui_result.context if ui_result else {},
            "ui_text": ui_result.text if ui_result else "",
            "ocr_context": {
                "ui_text_excerpt": enriched.get("ui_text_excerpt", ""),
                "ui_text_cached": enriched.get("ui_text_cached", False),
                "ui_ocr_provider": enriched.get("ui_ocr_provider", ""),
            },
            "stackoverflow_hint": stack_hint,
        }

    def _build_chat_prompt(
        self,
        *,
        user_text: str,
        ui_context: dict[str, object],
        session_goal: str,
        history: list[tuple[str, str]],
        web_result: str = "",
    ) -> str:
        history_lines: list[str] = []
        for role, content in history:
            if not content:
                continue
            prefix = "User" if role.lower().startswith("user") else "ARIA"
            history_lines.append(f"{prefix}: {content}")
        history_block = "\n".join(history_lines) if history_lines else "none"
        context_block = json.dumps(ui_context, ensure_ascii=True, indent=2)
        web_block = web_result.strip()
        return (
            "You are ARIA. Shwet's co-pilot.\n"
            "NOT a chatbot. NOT an assistant.\n"
            "A presence that lives on his screen.\n\n"
            "RULES - non-negotiable:\n"
            "No bullet points. Ever.\n"
            "No numbered lists. Ever.\n"
            "No markdown in responses.\n"
            "No **, no #, no backticks in speech.\n"
            "No 'Here is what you can do'\n"
            "No 'feel free to ask'\n"
            "No 'I can help you with'\n"
            "Maximum 3 sentences for any response\n"
            "Talk like a person, not documentation\n"
            "Answer in English only.\n"
            "Never invent filenames, errors, or UI text.\n"
            "If the screen context is empty or unclear, say 'screen context unavailable'.\n"
            "\n"
            "You know:\n"
            f"His name: Shwet\n"
            f"His project: ScreenSense\n"
            f"Current screen: {context_block}\n"
            f"His goal: {session_goal or 'none'}\n"
            f"Recent history: {history_block}\n"
            f"Time: {time.strftime('%H:%M', time.localtime())}\n\n"
            f"Web search result: {web_block}\n\n"
            f"User message: {user_text}\n"
            "ARIA:"
        )

    def _generate_response(self, prompt: str) -> str:
        if self._settings.reasoning_mode in {"local", "hybrid"}:
            local = self._generate_local_qwen(prompt)
            if local:
                return local
        if self._settings.reasoning_mode in {"gemini", "hybrid"}:
            return self._generate_gemini(prompt)
        return ""

    def _generate_local_qwen(self, prompt: str) -> str:
        if self._settings.local_llm_provider != "ollama":
            return ""
        payload = {
            "model": self._settings.local_llm_model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.3},
        }
        try:
            response = requests.post(
                f"{self._settings.local_llm_base_url.rstrip('/')}/api/generate",
                json=payload,
                timeout=self._settings.local_llm_timeout_seconds,
            )
            response.raise_for_status()
            data = response.json()
            return str(data.get("response") or "").strip()
        except Exception:
            self._record_error("local_llm_failed")
            return ""

    def _generate_gemini(self, prompt: str) -> str:
        if not self._settings.gemini_api_key.strip():
            return ""
        try:
            from google import genai
        except Exception:
            return ""
        try:
            client = genai.Client(api_key=self._settings.gemini_api_key)
            raw = client.models.generate_content(
                model=self._settings.gemini_model,
                contents=[{"text": prompt}],
            )
            return str(raw.text or "").strip()
        except Exception:
            self._record_error("gemini_failed")
            return ""

    def _execute_pending_action(self) -> str:
        action_fn = self._pending_action.action_fn
        if action_fn is None:
            return "no action queued."
        try:
            result = action_fn()
        except Exception as exc:
            return f"action failed: {exc}"
        return result or "done."

    def _log_skip(self) -> None:
        self._memory_db.add_telegram_message(role="assistant", content="skipped")

    def _build_status_summary(self) -> str:
        now = datetime.now()
        day_start = datetime(now.year, now.month, now.day).timestamp()
        count = self._memory_db.interaction_count_since(day_start)
        latest = self._memory_db.latest_interaction()
        goal = self._get_today_goal() or "no goal set"
        if latest:
            latest_text = (
                f"Latest: {latest.app} / {latest.aria_message} "
                f"({latest.outcome or 'unknown'})."
            )
        else:
            latest_text = "No interactions logged yet."
        return f"Today has {count} interactions. Goal: {goal}. {latest_text}"

    def _get_today_goal(self) -> str:
        return self._memory_db.get_goal(self._today_key())

    @staticmethod
    def _today_key() -> str:
        return time.strftime("%Y-%m-%d", time.localtime())

    def _days_to_deadline(self, now: datetime) -> int | None:
        if not self._settings.deadline_date:
            return None
        try:
            deadline = datetime.fromisoformat(self._settings.deadline_date).date()
        except ValueError:
            return None
        return (deadline - now.date()).days

    def _get_capturer(self) -> ScreenCapturer:
        capturer = getattr(self._capture_local, "capturer", None)
        if capturer is None:
            capturer = ScreenCapturer()
            self._capture_local.capturer = capturer
        return capturer

    def _record_error(self, message: str) -> None:
        self._last_error = message.strip()
        self._last_error_ts = time.time()

    def _approve_file_write(self, path: str, action_type: str) -> bool:
        preview = f"{action_type} {path}"
        return self._action_gate.approve(preview, "high")

    def _route_intent(self, text: str) -> str | None:
        lowered = text.lower().strip()
        if lowered == "status":
            git_status = self._code_ops.git_status()
            summary = self._build_status_summary()
            return f"{summary}\n{git_status}".strip()
        if lowered.startswith("what is in "):
            path = text.split(" ", 3)[-1].strip()
            return self._code_ops.read_file(path)
        if lowered.startswith(("read ", "show ")):
            path = text.split(" ", 1)[1].strip() if " " in text else ""
            return self._code_ops.read_file(path)
        if lowered.startswith(("search ", "find ", "look up ", "what is ")):
            query = text.split(" ", 1)[1].strip() if " " in text else ""
            return self._browser_ops.search_web(query)
        if lowered.startswith(("run ", "execute ", "test ")):
            parts = text.split(" ", 1)
            cmd = parts[1].strip() if len(parts) > 1 else ""
            return self._code_ops.run_command(cmd.split())
        if lowered.startswith("commit "):
            message = text.split(" ", 1)[1].strip()
            ok = self._code_ops.git_commit(message)
            return "done." if ok else "commit failed."
        if any(token in lowered for token in ("patch ", "fix ", "correct ")):
            parsed = _parse_patch_command(text)
            if parsed is None:
                return "format: patch <path> | <old> -> <new>"
            path, old_text, new_text = parsed
            ok = self._code_ops.patch_file(path, old_text, new_text)
            return "done." if ok else "patch failed."
        return None

    def set_goal_callback(self, callback: Callable[[str], str | None]) -> None:
        self._goal_callback = callback

    def set_health_callback(self, callback: Callable[[], str]) -> None:
        self._health_callback = callback

    def set_killlocal_callback(self, callback: Callable[[], str]) -> None:
        self._killlocal_callback = callback

    @staticmethod
    def _looks_like_token(token: str) -> bool:
        stripped = token.strip()
        if " " in stripped or "\n" in stripped or "\r" in stripped:
            return False
        if ":" not in stripped:
            return False
        if len(stripped) < 35:
            return False
        return True

    @staticmethod
    def _extract_error_text(ui_context: dict[str, object]) -> str:
        if not ui_context:
            return ""
        candidates = [
            str(ui_context.get("error_list") or ""),
            str(ui_context.get("terminal_last_output") or ""),
            str(ui_context.get("last_output") or ""),
            str(ui_context.get("any_dialog_text") or ""),
            str(ui_context.get("any_notification_text") or ""),
        ]
        for text in candidates:
            lowered = text.lower()
            if any(token in lowered for token in ("error", "exception", "traceback", "failed")):
                return text.strip()
        return ""


def _parse_patch_command(text: str) -> tuple[str, str, str] | None:
    match = re.search(r"patch\\s+(\\S+)\\s*\\|\\s*(.+?)\\s*->\\s*(.+)", text, flags=re.I)
    if not match:
        match = re.search(r"fix\\s+(\\S+)\\s*\\|\\s*(.+?)\\s*->\\s*(.+)", text, flags=re.I)
    if not match:
        match = re.search(r"correct\\s+(\\S+)\\s*\\|\\s*(.+?)\\s*->\\s*(.+)", text, flags=re.I)
    if not match:
        return None
    path = match.group(1).strip()
    old_text = match.group(2).strip()
    new_text = match.group(3).strip()
    if not path or not old_text:
        return None
    return path, old_text, new_text


def _extract_url(msg: str) -> str | None:
    match = re.search(r"https?://[^\\s]+", msg)
    if match:
        return match.group()

    match = re.search(
        r"\\b([a-zA-Z0-9-]+\\.(?:com|org|io|dev|net|ai|co|edu|gov))\\b",
        msg,
    )
    if match:
        return "https://" + match.group()

    match = re.search(
        r"(?:open|visit|go to|browse)\\s+([a-zA-Z0-9.-]+)",
        msg,
        re.IGNORECASE,
    )
    if match:
        name = match.group(1)
        if "." not in name:
            name = name + ".com"
        return "https://" + name

    return None


def _has_real_context(ui_context: dict[str, object]) -> bool:
    if not ui_context:
        return False
    ui_text = str(ui_context.get("ui_text") or "").strip()
    if ui_text:
        return True
    ocr = ui_context.get("ocr_context") or {}
    if isinstance(ocr, dict) and str(ocr.get("ui_text_excerpt") or "").strip():
        return True
    ui_ctx = ui_context.get("ui_context") or {}
    if isinstance(ui_ctx, dict) and ui_ctx:
        return True
    return False
